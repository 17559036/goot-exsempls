import { ANSWER_CELLS, ANSWER_FUNCTIONS } from './selectors'

/**
 * Возвращает первый символ
 * @param {string} text - Данные пользователя
 */
export const firstChar = (text) => text?.at(0)

/**
 * Возвращает количество слов
 * @param {string} text - Данные пользователя
 */
export const wordsCount = (text) => text?.split(' ')?.length

/**
 * Возвращает количество символов
 * @param {string} text - Данные пользователя
 */
export const charsCount = (text) => text?.length

/**
 * Возвращает слово с максимальной длиной
 * @param {string} text - Данные пользователя
 */
export const maxLengthWord = (text) => {
  const words = text?.split(' ')
  words?.sort((a, b) => b?.length - a?.length)
  return words?.[0]
}

/**
 * Возвращает перевернутое слово
 * @param {string} text - Данные пользователя
 */
export const reverseWord = (text) => {
  // Переворачиваем строку
  const reverseStr = text?.split('')?.reverse()?.join('')

  return reverseStr
}

/**
 * Возвращает количество предложений
 * @param {string} text - Данные пользователя
 */
export const sentencesCount = (text) => {
  const sentences = text?.split('.')
  return sentences?.length
}

/**
 * Возвращает количество уникальных слов
 * @param {string} text - Данные пользователя
 */
export const uniqueWordsCount = (text) => {
  const words = text?.split(' ')
  const uniqueWords = new Set(words)
  return uniqueWords?.size
}

/**
 * Возвращает строку отсортированную в алфавитном порядке
 * @param {string} text - Данные пользователя
 */
export const wordsAlphabetical = (text) => {
  const words = text?.split(' ')
  return words?.sort()?.join(' ')
}

/**
 * Основная функция для анализа текста
 * @param {string} text - Данные пользователя
 */
export const analyzeText = (text) => {
  ANSWER_CELLS?.forEach((cell) => {
    const key = cell.dataset.answer
    const func = ANSWER_FUNCTIONS[key]

    cell.textContent = func(text)
  })
}
